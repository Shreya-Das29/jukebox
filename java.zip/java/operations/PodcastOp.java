package operations;

import connection.DBConnection;
import entity.Podcast;

import java.sql.*;
import java.util.Scanner;

public class PodcastOp
{
    static Connection connection;

    static {
        try {
            connection = DBConnection.getConnection();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public void getAllPodcast() throws SQLException {
        Statement statement= connection.createStatement();
        ResultSet resultSet= statement.executeQuery("select * from podcast");
        while (resultSet.next()){
            int PodcastId= resultSet.getInt(1);
            String PodcastName= resultSet.getString(2);
            Time PodcastDuration=resultSet.getTime(3);
            Date PodcastReleaseDate=resultSet.getDate(4);
            String PodcastArtist= resultSet.getString(5);
            String PodcastCelebrity= resultSet.getString(6);

            Podcast obj=new Podcast(PodcastId,PodcastName,PodcastDuration,PodcastReleaseDate,PodcastArtist,PodcastCelebrity);
            System.out.println(obj);
        }
    }
    public void getPodcastByCeleb(String celeb) throws SQLException {
        String str="select * from podcast where PodcastCelebrity=?";
        PreparedStatement preparedStatement= connection.prepareStatement(str);
        preparedStatement.setString(1,celeb);
        ResultSet resultSet= preparedStatement.executeQuery();
        while (resultSet.next()){
            int PodcastId= resultSet.getInt(1);
            String PodcastName= resultSet.getString(2);
            Time PodcastDuration=resultSet.getTime(3);
            Date PodcastReleaseDate=resultSet.getDate(4);
            String PodcastArtist= resultSet.getString(5);
            String PodcastCelebrity= resultSet.getString(6);

            Podcast obj=new Podcast(PodcastId,PodcastName,PodcastDuration,PodcastReleaseDate,PodcastArtist,PodcastCelebrity);
            System.out.println(obj);
        }
    }
    public static void getPodcastByDate(Date rlsdt) throws SQLException {
        String str="select * from podcast where PodcastReleaseDate=?";
        PreparedStatement preparedStatement= connection.prepareStatement(str);
        preparedStatement.setDate(1,rlsdt);
        ResultSet resultSet= preparedStatement.executeQuery();
        while (resultSet.next()){
            int PodcastId= resultSet.getInt(1);
            String PodcastName= resultSet.getString(2);
            Time PodcastDuration=resultSet.getTime(3);
            Date PodcastReleaseDate=resultSet.getDate(4);
            String PodcastArtist= resultSet.getString(5);
            String PodcastCelebrity= resultSet.getString(6);

            Podcast obj=new Podcast(PodcastId,PodcastName,PodcastDuration,PodcastReleaseDate,PodcastArtist,PodcastCelebrity);
            System.out.println(obj);
        }
    }
/*
    public static void main(String[] args) throws SQLException {
        Scanner sc=new Scanner(System.in);
        System.out.println("Showing All Podcast");
        getAllPodcast();
        System.out.println("Choose Operation\n1.Search Podcast By Celebrity\n2.Search Podcast By Date");
        int choice=sc.nextInt();
        switch (choice){
            case 1:{
                System.out.println("Enter Celebrity Name");
                sc.nextLine();
                String celebName= sc.nextLine();
                System.out.println("Showing All podcast By Celebrity");
                getPodcastByCeleb(celebName);
                break;
            }
            case 2:{
                System.out.println("Enter Date");
                sc.nextLine();
                Date podDate= Date.valueOf(sc.nextLine());
                System.out.println("Showing All podcast By Date");
                getPodcastByDate(podDate);
            }
        }
    }

 */

}
