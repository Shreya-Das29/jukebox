package operations;

import connection.DBConnection;
import entity.Song;

import java.sql.*;
import java.util.Scanner;

public class SongOp
{
    static Connection connection;

    static {
        try {
            connection = DBConnection.getConnection();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public static void getAllSongs() throws SQLException {
        Statement statement=connection.createStatement();
        ResultSet resultSet= statement.executeQuery("select * from song");
        while (resultSet.next()){
            int SongId= resultSet.getInt(1);
            String SongName= resultSet.getString(2);
            Time SongDuration=resultSet.getTime(3);
            String AlbumName= resultSet.getString(4);
            String SongGenre=resultSet.getString(5);
            Date SongReleaseDate=resultSet.getDate(6);
            String SongArtist=resultSet.getString(7);

            Song obj=new Song(SongId,SongName,SongDuration,AlbumName,SongGenre,SongReleaseDate,SongArtist);
            System.out.println(obj);
        }
    }
    public static void getSongByArtist(String artistName) throws SQLException {
        String str="select * from song where SongArtist=?";
        PreparedStatement preparedStatement= connection.prepareStatement(str);
        preparedStatement.setString(1,artistName);
        ResultSet resultSet= preparedStatement.executeQuery();
        while (resultSet.next()){
            int SongId= resultSet.getInt(1);
            String SongName= resultSet.getString(2);
            Time SongDuration=resultSet.getTime(3);
            String AlbumName= resultSet.getString(4);
            String SongGenre=resultSet.getString(5);
            Date SongReleaseDate=resultSet.getDate(6);
            String SongArtist=resultSet.getString(7);

            Song obj=new Song(SongId,SongName,SongDuration,AlbumName,SongGenre,SongReleaseDate,SongArtist);
            System.out.println(obj);
        }
    }
    public static void getSongsByGenre(String songGenre) throws SQLException {
        String str="select * from song where songGenre=?";
        PreparedStatement preparedStatement= connection.prepareStatement(str);
        preparedStatement.setString(1,songGenre);
        ResultSet resultSet= preparedStatement.executeQuery();
        while (resultSet.next()){
            int SongId= resultSet.getInt(1);
            String SongName= resultSet.getString(2);
            Time SongDuration=resultSet.getTime(3);
            String AlbumName= resultSet.getString(4);
            String SongGenre=resultSet.getString(5);
            Date SongReleaseDate=resultSet.getDate(6);
            String SongArtist=resultSet.getString(7);

            Song obj=new Song(SongId,SongName,SongDuration,AlbumName,SongGenre,SongReleaseDate,SongArtist);
            System.out.println(obj);
        }
    }
    public static void getSongsByAlbum(String albumName) throws SQLException {
        String str="select * from song where albumName=?";
        PreparedStatement preparedStatement= connection.prepareStatement(str);
        preparedStatement.setString(1,albumName);
        ResultSet resultSet= preparedStatement.executeQuery();
        while (resultSet.next()){
            int SongId= resultSet.getInt(1);
            String SongName= resultSet.getString(2);
            Time SongDuration=resultSet.getTime(3);
            String AlbumName= resultSet.getString(4);
            String SongGenre=resultSet.getString(5);
            Date SongReleaseDate=resultSet.getDate(6);
            String SongArtist=resultSet.getString(7);

            Song obj=new Song(SongId,SongName,SongDuration,AlbumName,SongGenre,SongReleaseDate,SongArtist);
            System.out.println(obj);
        }
    }
/*
    public static void main(String[] args) throws SQLException {
        Scanner sc=new Scanner(System.in);
        System.out.println("Choose Operations \n1.Display All Songs\n2.Search Song By Artist\n3.Search Song By Genre\n4.Search Song By Album");
        int choice = sc.nextInt();
        switch (choice){
            case 1:{
                System.out.println("Showing All Songs");
                getAllSongs();
                break;
            }
            case 2:{
                System.out.println("Showing Songs By Artist");
                getSongByArtist("Darshan Raval");
                break;
            }
            case 3:{
                System.out.println("Showing songs by Genre");
                getSongsByGenre("Romantic");
                break;
            }
            case 4:{
                System.out.println("Showing songs by Album");
                getSongsByAlbum("Twilight");
                break;
            }
        }
//        System.out.println("Showing All Songs");
//        getAllSongs();
//        System.out.println("Showing Songs By Artist");
//        getSongByArtist("Darshan Raval");
//        System.out.println("Showing songs by Genre");
//        getSongsByGenre("Romantic");
//        System.out.println("Showing songs by Album");
//        getSongsByAlbum("Twilight");
    }

 */
}
