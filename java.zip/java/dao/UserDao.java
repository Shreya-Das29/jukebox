package dao;

import entity.User;

import java.util.List;

public interface UserDao
{
    public List<User> getAllUsers();
    public void addUser(User user);
    public boolean checkUser(String name,int id,String email,String pass);
    public int getuserId();
}
