package dao;

import entity.Podcast;

import java.util.Date;
import java.util.List;

public interface PodcastDao
{
    public List<Podcast> getAllPods();
    public List<Podcast>getPodsByDate(Date podDate);
    public List<Podcast>getPodsByCelebrity(String celeb);
    public boolean CheckIfPodcastIdIsPresent(int id);
}
