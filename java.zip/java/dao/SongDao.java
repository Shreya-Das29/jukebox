package dao;

import entity.Song;

import java.util.List;

public interface SongDao
{
    public List<Song> getAllSongs();
    public boolean CheckIfSongIdPresent(int id);
}
