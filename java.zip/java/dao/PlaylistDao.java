package dao;

import entity.Playlist;

import java.util.List;

public interface PlaylistDao {
    public List<Playlist> getPlaylists();
    public void createPlaylist(Playlist p);
    public void deletePlaylistbyId(int playlistId);
    public int getPlaylistID();
    public void addIntoPlaylist(Playlist p);
    public String getPlaylistName();
    public boolean CheckIfPlaylistIdPresent(int id);
}
