package dao;

import entity.Audio;

import java.util.List;

public interface AudioDao {
    public List<Audio> getAllAudio();
    public String getAudioName();
}
