package app;

import app.Play;
import dao.*;
import daoimpl.*;
import entity.*;
import operations.PodcastOp;
import operations.SongOp;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SongOperation {
    static UserDao ud=new UserDaoImpl();
    static SongDao sd=new SongDaoImpl();
    static PodcastDao pd=new PodcastDaoImpl();
    static PlaylistDao pl=new PlaylistDaoImpl();
    static AudioDao ad=new AudioDaoImpl();
    static PodcastOp po=new PodcastOp();
    static SongOp so=new SongOp();
    static String name,email,pass;
    static int id,u_id;
    static Scanner sc=new Scanner(System.in);

    public static void main(String[] args) throws UnsupportedAudioFileException, LineUnavailableException, IOException, SQLException {
        int currentuserid=0;
        int user_counter=5;
        System.out.println("-------------------------Welcome to JukeBox---------------------------");
        System.out.println("1.Login \n2.CreateAccount");
        int answer= sc.nextInt();
        int flag=0;

        switch (answer){
            case 1:{
                while (flag==0){
                    System.out.println("Enter Your Name");
                    sc.nextLine();
                    name=sc.nextLine();
                    System.out.println("Enter your UserId");
                    id=sc.nextInt();
 //                   System.out.println("Enter your Email");
 //                   email=sc.nextLine();
 //                   System.out.println("Enter your Pass");
 //                   pass=sc.nextLine();
                    boolean checkvalue=ud.checkUser(name,id,email,pass);
                    if (checkvalue==true){
                        System.out.println("Logged in successfully");
                        flag++;
                    }
                    else {
                        System.out.println("Please Enter correct info");
                    }
                    currentuserid=id;
                }
                break;
            }
            case 2:{
                u_id=ud.getuserId();
                System.out.println("Enter your name: ");
                sc.nextLine();
                String nameOFUser=sc.nextLine();
                System.out.println("Enter your Email: ");
                sc.nextLine();
                String userEmail= sc.nextLine();
                System.out.println("Enter Your Password");
                sc.nextLine();
                String pass= sc.nextLine();
                User user=new User(u_id+1,nameOFUser,userEmail,pass);
                ud.addUser(user);
                currentuserid=u_id+1;
                System.out.println("Your user id is: "+currentuserid);
                break;
            }
        }

        boolean y=true;
        while (y){
            System.out.println("\nEnter the operation you want to perform: \n1. Play Songs \n2. Play Podcasts \n3. Play Playlist \n4. Create Playlist \n5. Delete Playlist\n6. Add item to playlist");
            int choice=sc.nextInt();
            choice= sc.nextInt();
            switch (choice){
                case 1:{
//                    System.out.println("Select the operation \n1. Sort Songs based on artist \n2. Sort songs based on genre \n3. Sort songs based on album name");
                    List<Song> songList= sd.getAllSongs();
                    System.out.println("======================Song List======================");
                    for (Song s : songList) {
                        System.out.println(s);
                    }
                    System.out.println("\n******Select the operation****** \n1. Search Songs based on artist \n2. Search songs based on genre \n3. Search songs based on album name \n4. All Songs");
                    int userchoice= sc.nextInt();
                    switch(userchoice) {
                        case 1: {
                            System.out.println("Enter the name of artist:");
                            sc.nextLine();
                            String artist_name = sc.nextLine();
                            List<Song> sortedlist = new ArrayList<>();
                            songList.stream().filter(a -> a.getSongArtist().equals(artist_name)).forEach(b -> sortedlist.add(b));
                            for (Song s : sortedlist) {
                                System.out.println(s);
                            }
                            System.out.println("Enter song to be played");
                            String songName= sc.nextLine();
                            Play play=new Play();
                            play.PlaySong(songName,sortedlist);
                            break;
                        }
                        case 2:{
                            System.out.println("Enter Genre:");
                            sc.nextLine();
                            String genre_name = sc.nextLine();
                            List<Song> sortedlist = new ArrayList<>();
                            songList.stream().filter(a -> a.getSongGenre().equals(genre_name)).forEach(b -> sortedlist.add(b));
                            for (Song s : sortedlist) {
                                System.out.println(s);
                            }
                            System.out.println("Enter song to be played");
                            String songName= sc.nextLine();
                            Play play=new Play();
                            play.PlaySong(songName,sortedlist);
                            break;
                        }
                        case 3:{
                            System.out.println("Enter Album:");
                            sc.nextLine();
                            String album_name = sc.nextLine();
                            List<Song> sortedlist = new ArrayList<>();
                            songList.stream().filter(a -> a.getAlbumName().equals(album_name)).forEach(b -> sortedlist.add(b));
                            for (Song s : sortedlist) {
                                System.out.println(s);
                            }
                            System.out.println("Enter song to be played");
                            String songName= sc.nextLine();
                            Play play=new Play();
                            play.PlaySong(songName,sortedlist);
                            break;
                        }
                        case 4:{
                            System.out.println("Enter SongName:");
                            sc.nextLine();
                            String song_name = sc.nextLine();
                            List<Song> sortedlist = new ArrayList<>();
                            songList.stream().filter(a -> a.getSongName().equals(song_name)).forEach(b -> sortedlist.add(b));
                            for (Song s : sortedlist) {
                                System.out.println(s);
                            }
                            System.out.println("Enter song to be played");
                            String songName= sc.nextLine();
                            Play play=new Play();
                            play.PlaySong(songName,sortedlist);
                            break;
                        }
                    }
                    break;
                }
                case 2:{
                    List<Podcast> podcastList= pd.getAllPods();
                    System.out.println("======================Podcast List======================");
                    for (Podcast p : podcastList) {
                        System.out.println(p);
                    }
                    System.out.println("\n******Select the operation****** \n1. Search podcast based on celebrities \n2. Search podcast based on publish date. \n3. All Podcasts");
                    int userchoice= sc.nextInt();
                    switch (userchoice){
                        case 1:{
                            System.out.println("Enter the name celebrity:");
                            sc.nextLine();
                            String celeb_name = sc.nextLine();
//                            po.getPodcastByCeleb(celeb_name);
//                            List<Podcast> sortedlist=po.getPodcastByCeleb();
                            List<Podcast> sortedlist = new ArrayList<>();
                            podcastList.stream().filter(a -> a.getPodcastCelebrity().equals(celeb_name)).forEach(b -> sortedlist.add(b));
                            for (Podcast p : sortedlist) {
                                System.out.println(p);
                            }
                            System.out.println("Enter podcast to be played");
                            String podcastName= sc.nextLine();
                            Play play=new Play();
                            play.PlayPod(podcastName,sortedlist);
                            break;
                        }
                        case 2:{
                            System.out.println("Enter the publish date:");
                            sc.next();
                            String publishdate = sc.next();
                            List<Podcast> sortedlist = new ArrayList<>();
                            podcastList.stream().filter(a -> a.getPodcastReleaseDate().equals(publishdate)).forEach(b -> sortedlist.add(b));
                            for (Podcast p : sortedlist) {
                                System.out.println(p);
                            }
                            System.out.println("Enter podcast to be played");
                            String podcastName= sc.nextLine();
                            Play play=new Play();
                            play.PlayPod(podcastName,sortedlist);
                            break;
                        }
                    }
                    break;
                }
                case 3: {
                    List<Playlist> playlistList = pl.getPlaylists();
                    System.out.println("==================PlayList List==================");
                    for (Playlist pa : playlistList) {
                        System.out.println(pa);
                    }
                    System.out.println("\n******Select the operation****** \n1. Play Playlist based on playlistName ");
                    int userchoice = sc.nextInt();
//                    switch (userchoice) {
//                        case 1: {
                    if (userchoice==1){
                            System.out.println("Enter the playlistName:");
                            sc.nextLine();
                            String playlist_name = sc.nextLine();
                            List<Playlist> sortedlist = new ArrayList<>();
                            playlistList.stream().filter(a -> a.getPlaylistName().equals(playlist_name)).forEach(b -> sortedlist.add(b));
                            for (Playlist p : sortedlist) {
                                System.out.println(p);
                            }
                            System.out.println("Enter song to be played");
                            String playlistName = sc.nextLine();
                            Play play = new Play();
                            play.PlayPlaylist(playlistName, sortedlist);
                    }
                }
                break;
                case 4:{
//                    for (Audio audio : ad.getAllAudio()) {
//                        System.out.println(audio);
//                    }
                    System.out.println("Enter the audioName to be inserted");
                    String audio_name= sc.next();
//                    audio_name= ad.getAudioName();
                    int play_id=pl.getPlaylistID();
//                    int audio_id=ad.getAudioID();
                    //audio_name= ad.getAudioName();
                    sc.nextLine();
                    System.out.println("Enter the name of the playlist");
                    String nameChoice= sc.nextLine();
                    Playlist p=new Playlist(play_id+1,audio_name,nameChoice,currentuserid);
                    PlaylistDao playlistDao=new PlaylistDaoImpl();
                    playlistDao.createPlaylist(p);
                    List<Playlist>updatedPlaylists= playlistDao.getPlaylists();
                    System.out.println("======================Updated Playlist======================");
                    for(Playlist pl: updatedPlaylists){
                        System.out.println(pl);
                    }
                    break;
                }
                case 5:{
                    System.out.println("======================My Playlists======================");
                    for (Playlist pl1 : pl.getPlaylists()) {
                        System.out.println(pl1);
                    }
                    sc.nextLine();
                    System.out.println("Enter id of playlist to be deleted: ");
                    int playlist_id = sc.nextInt();
                    pl.deletePlaylistbyId(playlist_id);
                    System.out.println("======================Updated Playlist======================");
                    List<Playlist> playlists=pl.getPlaylists();
                    for(Playlist play:playlists){
                        System.out.println(play);
                    }
                    break;
                }
                case 6:{
                    System.out.println("====================My Playlist=====================");
                    for (Playlist pl2:pl.getPlaylists()) {
                        System.out.println(pl2);
                    }
                    sc.nextLine();
                    System.out.println("Enter the playlistId where you want to add");
                    int playlist_id= sc.nextInt();
                    playlist_id=pl.getPlaylistID();
                    sc.nextLine();
                    System.out.println("Enter the audioName to be inserted");
                    String audioName= sc.nextLine();
//                    audioName= ad.getAudioName();
                    int play_id=pl.getPlaylistID();
                    sc.nextLine();
                    System.out.println("Enter the playlistName where you want to add");
                    String playlist_name= sc.nextLine();
                    playlist_name=pl.getPlaylistName();
                    sc.nextLine();
                    Playlist p=new Playlist(playlist_id,audioName,playlist_name,currentuserid);
                    PlaylistDao playlistDao=new PlaylistDaoImpl();
                    playlistDao.addIntoPlaylist(p);
                    List<Playlist>updatedPlaylists= playlistDao.getPlaylists();
                    System.out.println("======================Updated Playlist======================");
                    for(Playlist pl: updatedPlaylists){
                        System.out.println(pl);
                    }
                    break;
                }
                case 7:{
                    y=false;
                    break;
                }
            }
        }
    }
}
