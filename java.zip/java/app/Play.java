package app;

import entity.Audio;
import entity.Playlist;
import entity.Podcast;
import entity.Song;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Play
{
    public void PlaySong(String songName, List<Song> songList)throws UnsupportedAudioFileException,IOException,LineUnavailableException {
        Scanner scanner = new Scanner(System.in);
        try {
            String path = "src/main/resources/"+songName+".wav";
            File file = new File(path);
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(file);
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            String response = "";

            while (!response.equals("Q")) {
                System.out.println("P=Play, T= Pause, S=Stop, L=Loop, F=Forward, B=Reverse, R = Reset, N=Next Song Q = Quit");
                System.out.println("Enter Your Choice");
                response = scanner.next();
                response = response.toUpperCase();

                switch (response) {
                    case ("P"): {
                        clip.start();
                        long clip_pos = clip.getMicrosecondPosition();
                        long milli_sec = clip_pos / 1000;
                        System.out.println("Songs in queue");
                        SongsLeft(songName, songList);
                        break;
                    }
                    case ("T"): {
                        clip.stop();
                        long clip_position = clip.getMicrosecondPosition();
                        long milliseconds = clip_position / 1000;
                        System.out.println("Clip stopped at: " + milliSecondsToTimer(milliseconds));
                        break;
                    }
                    case ("S"): {
                        clip.setMicrosecondPosition(0);
                        clip.stop();
                        break;
                    }
                    case ("L"): {
                        clip.start();
                        clip.loop(Clip.LOOP_CONTINUOUSLY);
                    }
                    case ("F"): {
                        long duration = clip.getFrameLength();

                        long clip_position = clip.getMicrosecondPosition();
                        if ((duration - clip_position) > 10000000) {
                            clip.setMicrosecondPosition(clip.getMicrosecondPosition() + 10000000);
                            clip.start();

                        }
                        long milliseconds = clip.getMicrosecondPosition() / 1000;
                        System.out.println("Clip played from: " + milliSecondsToTimer(milliseconds));
                        break;
                    }
                    case ("B"): {
                        clip.start();
                        long clip_position = clip.getMicrosecondPosition();
                        if (clip_position < 10000000) {
                            clip.setMicrosecondPosition(0);
                        } else {
                            clip.setMicrosecondPosition(clip_position - 10000000);
                        }
                        clip.start();
                        long milliseconds = clip_position / 1000;
                        System.out.println("Clip played from: " + milliSecondsToTimer(milliseconds));
                        break;
                    }
                    case ("R"):
                        clip.setMicrosecondPosition(0);
                        break;
                    case ("N"): {
                        SongsLeft(songName, songList);
                        System.out.println("Choose the song to be played next: ");
                        scanner.nextLine();
                        String song = scanner.nextLine();
                        PlaySong(song, songList);
                        break;
                    }
                    case ("Q"):
                        clip.close();
                        break;
                    default:
                        System.out.println("Not a valid response");
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public void PlayPod(String podcastname, List<Podcast> podcastList) throws UnsupportedAudioFileException, IOException, LineUnavailableException {

        Scanner scanner = new Scanner(System.in);
        try{
            String path="src/main/resources/"+podcastname+".wav";
            File file = new File(path);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);

            String response = "";

            while(!response.equals("Q")) {
                System.out.println("P = play, T= Resume, S=Stop, L=Loop, F=Forward, B=Reverse, R = Reset, N=Next Episode Q = Quit");
                System.out.print("Enter your choice: ");

                response = scanner.next();
                response = response.toUpperCase();

                switch(response) {
                    case ("P"): {
                        clip.start();
                        long clip_position = clip.getMicrosecondPosition();
                        long milliseconds=clip_position/1000;
                        System.out.println("Clip played from: "+milliSecondsToTimer(milliseconds));
                        PodcastLeft(podcastname,podcastList);
                        break;
                    }
                    case ("T"): {
                        clip.stop();
                        long clip_position = clip.getMicrosecondPosition();
                        long milliseconds=clip_position/1000;
                        System.out.println("Clip stopped at: "+milliSecondsToTimer(milliseconds));
                        break;
                    }
                    case("S"):{
                        clip.setMicrosecondPosition(0);
                        clip.stop();
                        break;
                    }
                    case("L"):{
                        clip.start();
                        clip.loop(Clip.LOOP_CONTINUOUSLY);
                    }
                    case("F"):{
                        long duration=clip.getFrameLength();
                        long clip_position = clip.getMicrosecondPosition();
                        if((duration-clip_position)>10000000){
                            clip.setMicrosecondPosition(clip.getMicrosecondPosition()+10000000);
                            clip.start();
                        }
                        long milliseconds=clip.getMicrosecondPosition()/1000;
                        System.out.println("Clip played from: "+milliSecondsToTimer(milliseconds));
                        break;
                    }
                    case("B"):{
                        clip.start();
                        long clip_position = clip.getMicrosecondPosition();
                        if(clip_position<10000000){
                            clip.setMicrosecondPosition(0);
                        }
                        else{
                            clip.setMicrosecondPosition(clip_position-10000000);
                        }
                        clip.start();
                        long milliseconds=clip_position/1000;
                        System.out.println("Clip played from: "+milliSecondsToTimer(milliseconds));
                        break;
                    }
                    case ("R"): clip.setMicrosecondPosition(0);
                        break;
                    case ("N"): {

                        PodcastLeft(podcastname,podcastList);
                        System.out.println("\nChoose the episode to be played next: ");
                        scanner.nextLine();
                        String podcast=scanner.nextLine();
                        PlayPod(podcast,podcastList);
                        break;
                    }
                    case ("Q"): clip.close();
                        break;
                    default: System.out.println("Not a valid response");
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }

    }
    public void PlayPlaylist(String playlistName, List<Playlist> playlistList)throws UnsupportedAudioFileException,IOException,LineUnavailableException {
        Scanner scanner = new Scanner(System.in);
        try {
            String path = "src/main/resources/"+playlistName+".wav";
            File file = new File(path);
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(file);
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            String response = "";

            while (!response.equals("Q")) {
                System.out.println("P=Play, T= Pause, S=Stop, L=Loop, F=Forward, B=Reverse, R = Reset, N=Next Song Q = Quit");
                System.out.println("Enter Your Choice");
                response = scanner.next();
                response = response.toUpperCase();

                switch (response) {
                    case ("P"): {
                        clip.start();
                        long clip_pos = clip.getMicrosecondPosition();
                        long milli_sec = clip_pos / 1000;
                        System.out.println("Songs in queue");
                        SongsLeftInPlaylist(playlistName, playlistList);
                        break;
                    }
                    case ("T"): {
                        clip.stop();
                        long clip_position = clip.getMicrosecondPosition();
                        long milliseconds = clip_position / 1000;
                        System.out.println("Clip stopped at: " + milliSecondsToTimer(milliseconds));
                        break;
                    }
                    case ("S"): {
                        clip.setMicrosecondPosition(0);
                        clip.stop();
                        break;
                    }
                    case ("L"): {
                        clip.start();
                        clip.loop(Clip.LOOP_CONTINUOUSLY);
                    }
                    case ("F"): {
                        long duration = clip.getFrameLength();

                        long clip_position = clip.getMicrosecondPosition();
                        if ((duration - clip_position) > 10000000) {
                            clip.setMicrosecondPosition(clip.getMicrosecondPosition() + 10000000);
                            clip.start();

                        }
                        long milliseconds = clip.getMicrosecondPosition() / 1000;
                        System.out.println("Clip played from: " + milliSecondsToTimer(milliseconds));
                        break;
                    }
                    case ("B"): {
                        clip.start();
                        long clip_position = clip.getMicrosecondPosition();
                        if (clip_position < 10000000) {
                            clip.setMicrosecondPosition(0);
                        } else {
                            clip.setMicrosecondPosition(clip_position - 10000000);
                        }
                        clip.start();
                        long milliseconds = clip_position / 1000;
                        System.out.println("Clip played from: " + milliSecondsToTimer(milliseconds));
                        break;
                    }
                    case ("R"):
                        clip.setMicrosecondPosition(0);
                        break;
                    case ("N"): {
                        SongsLeftInPlaylist(playlistName, playlistList);
                        System.out.println("Choose the song to be played next: ");
                        scanner.nextLine();
                        String playlist = scanner.nextLine();
                        PlayPlaylist(playlist,playlistList);
                        break;
                    }
                    case ("Q"):
                        clip.close();
                        break;
                    default:
                        System.out.println("Not a valid response");
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public static String milliSecondsToTimer(long milliseconds) {
        String finalTimerString = "";
        String secondsString = "";

        // Convert total duration into time
        int hours = (int) (milliseconds / (1000 * 60 * 60));
        int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
        int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
        if (hours > 0) {
            finalTimerString = hours + ":";
        }
        if (seconds < 10) {
            secondsString = "0" + seconds;
        }   else {
            secondsString = "" + seconds;
        }
        finalTimerString = finalTimerString + minutes + ":" + secondsString;
        return finalTimerString;
    }
    public static void SongsLeft(String song_name, List<Song> songslist){
        songslist.stream().filter(a->!a.getSongName().equals(song_name)).forEach(b-> System.out.println(b));
    }
    public static void PodcastLeft(String podcast_name, List<Podcast> podcastList){
        podcastList.stream().filter(a->!a.getPodcastName().equals(podcast_name)).forEach(b-> System.out.println(b));
    }
    public static void SongsLeftInPlaylist(String playlist_name, List<Playlist> playlistList){
        playlistList.stream().filter(a->!a.getPlaylistName().equals(playlist_name)).forEach(b-> System.out.println(b));
    }
}
