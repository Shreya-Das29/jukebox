package daoimpl;

import connection.DBConnection;
import dao.AudioDao;
import entity.Audio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AudioDaoImpl implements AudioDao {
    public List<Audio> getAllAudio() {
        List<Audio> audioList=new ArrayList<>();
        try(Connection con=new DBConnection().getConnection()){
            PreparedStatement prs=con.prepareStatement("select * from audios");
            ResultSet rs=prs.executeQuery();
            while(rs.next()){
                audioList.add(new Audio(rs.getInt(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getInt(4),
                        rs.getBoolean(4)));
            }
        }
        catch(SQLException e){
            System.out.println(e);
        }
        return audioList;
    }
    public String getAudioName() {
        try (Connection con = DBConnection.getConnection()) {
            Statement stmnt = con.createStatement();
//            ResultSet rs=stmnt.executeQuery("select AudioName from audios order by AudioName desc limit 1");
            ResultSet rs=stmnt.executeQuery("select AudioName from audios");
            rs.next();
            String audioName=rs.getString(1);
            return audioName;

        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }
}
