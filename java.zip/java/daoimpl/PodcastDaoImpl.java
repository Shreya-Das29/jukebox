package daoimpl;

import connection.DBConnection;
import dao.PodcastDao;
import entity.Podcast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PodcastDaoImpl implements PodcastDao
{
    List<Podcast> pods=new ArrayList<>();

    public List<Podcast> getAllPods() {
        try (Connection con=new DBConnection().getConnection()){
            PreparedStatement pr= con.prepareStatement("select * from podcast");
            ResultSet resultSet= pr.executeQuery();
            while (resultSet.next()){
                pods.add(new Podcast(resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getTime(3),
                        resultSet.getDate(4),
                        resultSet.getString(5),
                        resultSet.getString(6)));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return pods;
    }
    public List<Podcast>getPodsByDate(Date podDate){
        try (Connection connection=DBConnection.getConnection()){
            PreparedStatement preparedStatement= connection.prepareStatement("select * from podcast where PodcastReleaseDate= ?");
            preparedStatement.setDate(1, (java.sql.Date) podDate);
            ResultSet rs=preparedStatement.executeQuery();
            while (rs.next()){
                pods.add(new Podcast(rs.getInt(1),
                        rs.getString(2),
                        rs.getTime(3),
                        rs.getDate(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return pods;
    }
    public List<Podcast>getPodsByCelebrity(String celeb){
        try (Connection connection=DBConnection.getConnection()){
            PreparedStatement preparedStatement= connection.prepareStatement("select * from podcast where PodcastCelebrity= ?");
            preparedStatement.setString(1, celeb);
            ResultSet rs=preparedStatement.executeQuery();
            while (rs.next()){
                pods.add(new Podcast(rs.getInt(1),
                        rs.getString(2),
                        rs.getTime(3),
                        rs.getDate(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return pods;
    }
    public boolean CheckIfPodcastIdIsPresent(int id) {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement prs = con.prepareStatement("select * from podcast where PodcastId='"+id+"' ");
            ResultSet rs=prs.executeQuery();
            while(rs.next()){
                int id_check=rs.getInt(1);
                if(id_check!=0){
                    return true;
                }
            }
        }
        catch (SQLException e){
            System.out.println(e);
        }
        return false;
    }
}
