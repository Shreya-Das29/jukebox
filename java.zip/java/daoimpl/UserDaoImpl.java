package daoimpl;

import connection.DBConnection;
import dao.UserDao;
import entity.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {
    List<User> users=new ArrayList<>();

    public List<User> getAllUsers() {
        try (Connection connection= DBConnection.getConnection()){
            PreparedStatement prs= connection.prepareStatement("select * from user");
            ResultSet resultSet= prs.executeQuery();
            while (resultSet.next()){
                users.add(new User(resultSet.getInt(1),resultSet.getString(2),resultSet.getString(3),resultSet.getString(4)));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return users;
    }
    public void addUser(User user){
        try (Connection connection=DBConnection.getConnection()){
            PreparedStatement pr= connection.prepareStatement("insert into user values(?,?,?,?)");
            pr.setInt(1,user.getUserid());
            pr.setString(2,user.getUserName());
            pr.setString(3, user.getUserEmail());
            pr.setString(4, user.getUserPassword());
            int rows=pr.executeUpdate();
            if (rows>0){
                System.out.println("\nUser Account created successfully");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public boolean checkUser(String name,int id,String email,String pass){
        try (Connection connection=DBConnection.getConnection()){
            PreparedStatement pr= connection.prepareStatement("select UserId from user where UserName=?");
            pr.setString(1,name);
            ResultSet resultSet= pr.executeQuery();
            while (resultSet.next()){
                int idd=resultSet.getInt(1);
                if (idd==id){
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return false;
    }
    public int getuserId() {
        try (Connection con = DBConnection.getConnection()) {
            Statement stmnt = con.createStatement();
            ResultSet rs=stmnt.executeQuery("select user_id from user order by user_id desc limit 1");
            rs.next();
            int userid=rs.getInt(1);
            return userid;

        } catch (SQLException e) {
            System.out.println(e);
        }
        return 0;
    }
}
