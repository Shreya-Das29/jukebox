package daoimpl;

import connection.DBConnection;
import dao.SongDao;
import entity.Song;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SongDaoImpl implements SongDao
{
    List<Song> songs=new ArrayList<>();

    public List<Song> getAllSongs(){
        try (Connection connection= DBConnection.getConnection()){
            PreparedStatement pr = connection.prepareStatement("select * from song");
            ResultSet resultSet= pr.executeQuery();
            while (resultSet.next()){
                songs.add(new Song(resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getTime(3),
                        resultSet.getString(4),
                        resultSet.getString(5),
                        resultSet.getDate(6),
                        resultSet.getString(7)));
            }
        }
        catch (SQLException e) {
            System.out.println(e);
        }
        return songs;
    }
    public boolean CheckIfSongIdPresent(int id) {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement prs = con.prepareStatement("select * from song where SongId='"+id+"' ");
            ResultSet rs=prs.executeQuery();
            while(rs.next()){
                int id_check=rs.getInt(1);
                if(id_check!=0){
                    return true;
                }
            }
        }
        catch (SQLException e){
            System.out.println(e);
        }
        return false;
    }
}
