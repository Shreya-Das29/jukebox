package daoimpl;

import connection.DBConnection;
import dao.PlaylistDao;
import entity.Playlist;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlaylistDaoImpl implements PlaylistDao {

    List<Playlist> playlists=new ArrayList<>();

    public List<Playlist> getPlaylists() {
        try (Connection connection= DBConnection.getConnection()){
            PreparedStatement pr= connection.prepareStatement("select * from playlists");
            ResultSet resultSet= pr.executeQuery();
            while (resultSet.next()){
                playlists.add(new Playlist(resultSet.getInt(1),
                        resultSet.getString(2),
                        resultSet.getString(3),
                        resultSet.getInt(4)));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return playlists;
    }
    public void createPlaylist(Playlist p){
        try (Connection connection=DBConnection.getConnection()){
            PreparedStatement preparedStatement= connection.prepareStatement("insert into playlists values(?,?,?,?)");
            preparedStatement.setInt(1,p.getPlaylistId());
            preparedStatement.setString(2,p.getAudioName());
            preparedStatement.setString(3,p.getPlaylistName());
            preparedStatement.setInt(4,p.getUserId());
            int rows=preparedStatement.executeUpdate();
            if (rows>0){
                System.out.println("\nPlaylist Created");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public void deletePlaylistbyId(int playlistId){
        try (Connection connection=DBConnection.getConnection()){
            PreparedStatement preparedStatement= connection.prepareStatement("delete from playlists where playlistId=?");
            preparedStatement.setInt(1,playlistId);
            int rows=preparedStatement.executeUpdate();
            if (rows>0){
                System.out.println("\nPlaylist Deleted");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public int getPlaylistID() {
        try (Connection con = DBConnection.getConnection()) {
            Statement stmnt = con.createStatement();
            ResultSet rs=stmnt.executeQuery("select PlaylistId from playlists order by PlaylistId desc limit 1");
            rs.next();
            int playlistId=rs.getInt(1);
            return playlistId;

        } catch (SQLException e) {
            System.out.println(e);
        }
        return 0;
    }
    public void addIntoPlaylist(Playlist p){
        try (Connection connection=DBConnection.getConnection()){
            PreparedStatement preparedStatement= connection.prepareStatement("insert into playlists values(?,?,?,?)");
            preparedStatement.setInt(1,p.getPlaylistId());
            preparedStatement.setString(2,p.getAudioName());
            preparedStatement.setString(3,p.getPlaylistName());
            preparedStatement.setInt(4,p.getUserId());
            int rows=preparedStatement.executeUpdate();
            if (rows>0){
                System.out.println("\nAdded into playlist");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    public String getPlaylistName() {
        try (Connection con = DBConnection.getConnection()) {
            Statement stmnt = con.createStatement();
            ResultSet rs=stmnt.executeQuery("select PlaylistName from playlists order by PlaylistName desc limit 1");
            rs.next();
            String playlistName=rs.getString(1);
            return playlistName;

        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }
    public boolean CheckIfPlaylistIdPresent(int id) {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement prs = con.prepareStatement("select * from playlists where PlaylistId='"+id+"' ");
            ResultSet rs=prs.executeQuery();
            while(rs.next()){
                int id_check=rs.getInt(1);
                if(id_check!=0){
                    return true;
                }
            }
        }
        catch (SQLException e){
            System.out.println(e);
        }
        return false;
    }
}
