package operation;

import dao.PodcastDao;
import daoimpl.PodcastDaoImpl;
import entity.Podcast;
import entity.Song;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class PodcastOperation
{
    static PodcastDao pd=new PodcastDaoImpl();
    static Scanner sc=new Scanner(System.in);

    public static void main(String[] args) {
        List<Podcast>podList=pd.getAllPods();
        System.out.println("========================PodCastList=========================");
        for (Podcast p:podList) {
            System.out.println(p);
        }
        System.out.println("Choose Operation\n1.Search By Date\n2.Search By Celebrity");
        int choice=sc.nextInt();
        switch (choice){
            case 1:{
                List<Podcast> byDate=pd.getPodsByDate((Date) podList);
                for (Podcast podcast:byDate) {
                    System.out.println(podcast);
                }
                break;
            }
            case 2:{
                List<Podcast> byCeleb=pd.getPodsByCelebrity(String.valueOf(podList));
                for (Podcast podcast:byCeleb) {
                    System.out.println(podcast);
                }
                break;
            }
        }
    }
}
