package entity;

public class Playlist
{
    int PlaylistId;
    String AudioName;
    String PlaylistName;
    int UserId;

    public Playlist(int playlistId, String audioName, String playlistName, int userId) {
        PlaylistId = playlistId;
        AudioName=audioName;
        PlaylistName = playlistName;
        UserId = userId;
    }

    public int getPlaylistId() {
        return PlaylistId;
    }

    public void setPlaylistId(int playlistId) {
        PlaylistId = playlistId;
    }

    public String getAudioName() {
        return AudioName;
    }

    public void setAudioId(String audioName) {
        AudioName=audioName;
    }

    public String getPlaylistName() {
        return PlaylistName;
    }

    public void setPlaylistName(String playlistName) {
        PlaylistName = playlistName;
    }

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

    @Override
    public String toString() {
        return "Playlist{" +
                "PlaylistId=" + PlaylistId +
                ", AudioName=" + AudioName +
                ", PlaylistName='" + PlaylistName + '\'' +
                ", UserId=" + UserId +
                '}';
    }
}
