package entity;

import java.sql.Date;
import java.sql.Time;

public class Song
{
    int SongId;
    String SongName;
    Time SongDuration;
    String AlbumName;
    String SongGenre;
    Date SongReleaseDate;
    String SongArtist;

    public Song(int songId, String songName, Time songDuration, String albumName, String songGenre, Date songReleaseDate, String songArtist) {
        SongId = songId;
        SongName = songName;
        SongDuration = songDuration;
        AlbumName = albumName;
        SongGenre = songGenre;
        SongReleaseDate = songReleaseDate;
        SongArtist = songArtist;
    }

    public int getSongId() {
        return SongId;
    }

    public void setSongId(int songId) {
        SongId = songId;
    }

    public String getSongName() {
        return SongName;
    }

    public void setSongName(String songName) {
        SongName = songName;
    }

    public Time getSongDuration() {
        return SongDuration;
    }

    public void setSongDuration(Time songDuration) {
        SongDuration = songDuration;
    }

    public String getAlbumName() {
        return AlbumName;
    }

    public void setAlbumName(String albumName) {
        AlbumName = albumName;
    }

    public String getSongGenre() {
        return SongGenre;
    }

    public void setSongGenre(String songGenre) {
        SongGenre = songGenre;
    }

    public Date getSongReleaseDate() {
        return SongReleaseDate;
    }

    public void setSongReleaseDate(Date songReleaseDate) {
        SongReleaseDate = songReleaseDate;
    }

    public String getSongArtist() {
        return SongArtist;
    }

    public void setSongArtist(String songArtist) {
        SongArtist = songArtist;
    }

    @Override
    public String toString() {
        return "Song{" +
                "SongId=" + SongId +
                ", SongName='" + SongName + '\'' +
                ", SongDuration=" + SongDuration +
                ", AlbumName='" + AlbumName + '\'' +
                ", SongGenre='" + SongGenre + '\'' +
                ", SongReleaseDate=" + SongReleaseDate +
                ", SongArtist='" + SongArtist + '\'' +
                '}';
    }
}
