package entity;

import java.sql.Date;
import java.sql.Time;

public class Podcast
{
    int PodcastId;
    String PodcastName;
    Time PodcastDuration;
    Date PodcastReleaseDate;
    String PodcastArtist;
    String PodcastCelebrity;

    public Podcast(int podcastId, String podcastName, Time podcastDuration, Date podcastReleaseDate, String podcastArtist, String podcastCelebrity) {
        PodcastId = podcastId;
        PodcastName = podcastName;
        PodcastDuration = podcastDuration;
        PodcastReleaseDate = podcastReleaseDate;
        PodcastArtist = podcastArtist;
        PodcastCelebrity = podcastCelebrity;
    }

    public int getPodcastId() {
        return PodcastId;
    }

    public void setPodcastId(int podcastId) {
        PodcastId = podcastId;
    }

    public String getPodcastName() {
        return PodcastName;
    }

    public void setPodcastName(String podcastName) {
        PodcastName = podcastName;
    }

    public Time getPodcastDuration() {
        return PodcastDuration;
    }

    public void setPodcastDuration(Time podcastDuration) {
        PodcastDuration = podcastDuration;
    }

    public Date getPodcastReleaseDate() {
        return PodcastReleaseDate;
    }

    public void setPodcastReleaseDate(Date podcastReleaseDate) {
        PodcastReleaseDate = podcastReleaseDate;
    }

    public String getPodcastArtist() {
        return PodcastArtist;
    }

    public void setPodcastArtist(String podcastArtist) {
        PodcastArtist = podcastArtist;
    }

    public String getPodcastCelebrity() {
        return PodcastCelebrity;
    }

    public void setPodcastCelebrity(String podcastCelebrity) {
        PodcastCelebrity = podcastCelebrity;
    }

    @Override
    public String toString() {
        return "Podcast{" +
                "PodcastId=" + PodcastId +
                ", PodcastName='" + PodcastName + '\'' +
                ", PodcastDuration=" + PodcastDuration +
                ", PodcastReleaseDate=" + PodcastReleaseDate +
                ", PodcastArtist='" + PodcastArtist + '\'' +
                ", PodcastCelebrity='" + PodcastCelebrity + '\'' +
                '}';
    }
}
