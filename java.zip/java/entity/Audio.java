package entity;

public class Audio
{
    int audioId;
    String audioName;
    int songId;
    int podcastId;
    boolean audioType;

    public Audio(int audioId,String audioName, int songId, int podcastId, boolean audioType) {
        this.audioName=audioName;
        this.audioId = audioId;
        this.songId = songId;
        this.podcastId = podcastId;
        this.audioType = audioType;
    }

    public int getAudioId() {
        return audioId;
    }

    public void setAudioId(int audioId) {
        this.audioId = audioId;
    }

    public String getAudioName(){ return audioName; }

    public void setAudioName(String audioName){ this.audioName=audioName; }

    public int getSongId() {
        return songId;
    }

    public void setSongId(int songId) {
        this.songId = songId;
    }

    public int getPodcastId() {
        return podcastId;
    }

    public void setPodcastId(int podcastId) {
        this.podcastId = podcastId;
    }

    public boolean isAudioType() {
        return audioType;
    }

    public void setAudioType(boolean audioType) {
        this.audioType = audioType;
    }

    @Override
    public String toString() {
        return "Audio{" +
                "audioId=" + audioId +
                "audioName=" + audioName +
                ", songId=" + songId +
                ", podcastId=" + podcastId +
                ", audioType=" + audioType +
                '}';
    }
}
