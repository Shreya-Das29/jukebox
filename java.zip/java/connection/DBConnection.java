package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection
{
    static Connection connection;
    public static Connection getConnection() throws SQLException {
        connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/jukebox","root","root");
        return connection;
    }
}
